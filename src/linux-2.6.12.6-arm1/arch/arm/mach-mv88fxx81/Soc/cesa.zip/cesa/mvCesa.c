/*******************************************************************************
Copyright (C) Marvell International Ltd. and its affiliates

This software file (the "File") is owned and distributed by Marvell 
International Ltd. and/or its affiliates ("Marvell") under the following
alternative licensing terms.  Once you have made an election to distribute the
File under one of the following license alternatives, please (i) delete this
introductory statement regarding license alternatives, (ii) delete the two
license alternatives that you have not elected to use and (iii) preserve the
Marvell copyright notice above.

********************************************************************************
Marvell Commercial License Option

If you received this File from Marvell and you have entered into a commercial
license agreement (a "Commercial License") with Marvell, the File is licensed
to you under the terms of the applicable Commercial License.

********************************************************************************
Marvell GPL License Option

If you received this File from Marvell, you may opt to use, redistribute and/or 
modify this File in accordance with the terms and conditions of the General 
Public License Version 2, June 1991 (the "GPL License"), a copy of which is 
available along with the File in the license.txt file or by writing to the Free 
Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 or 
on the worldwide web at http://www.gnu.org/licenses/gpl.txt. 

THE FILE IS DISTRIBUTED AS-IS, WITHOUT WARRANTY OF ANY KIND, AND THE IMPLIED 
WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY 
DISCLAIMED.  The GPL License provides additional details about this warranty 
disclaimer.
********************************************************************************
Marvell BSD License Option

If you received this File from Marvell, you may opt to use, redistribute and/or 
modify this File under the following licensing terms. 
Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    *   Redistributions of source code must retain the above copyright notice,
        this list of conditions and the following disclaimer. 

    *   Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution. 

    *   Neither the name of Marvell nor the names of its contributors may be 
        used to endorse or promote products derived from this software without 
        specific prior written permission. 
    
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR 
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*******************************************************************************/

#include "mvOs.h"
#include "mvDebug.h"

#include "mvIdma.h"
#include "mvMD5.h"
#include "mvSHA1.h"

#include "mvCesa.h"
#include "mvCesaRegs.h"
#include "mvAes.h"
#include "mvLru.h"

#define CESA_DEBUG


#ifdef MV_88F5182
#define MV_CESA_FRAGS_WA
#else
#undef MV_CESA_FRAGS_WA
#endif

/* Global variables */
MV_BOOL                 cesaLargeInProc = MV_FALSE;

MV_CESA_STATS           cesaStats;   
MV_CESA_FRAGS           cesaFrags;
MV_LRU_CACHE*           pCesaCacheLRU = NULL;

MV_CESA_SA*             pCesaSAD = NULL;
MV_U16                  cesaMaxSA = 0;

MV_CESA_REQ*            pCesaReqFirst = NULL;
MV_CESA_REQ*            pCesaReqLast = NULL;
MV_CESA_REQ*            pCesaReqEmpty = NULL;
MV_CESA_REQ*            pCesaReqProcess = NULL;
MV_CESA_REQ*            pCesaReqReady = NULL;
int                     cesaQueueDepth = 0;
int                     cesaReqResources = 0;

MV_CESA_SRAM_MAP*       cesaSramVirtPtr = NULL;

MV_CESA_CHAN            pCesaChan[MV_CESA_MAX_CHAN];

MV_U32                  cesaChanReadyMap = 0;


MV_U8*  mvCesaSramAddrGet(void)
{
#ifdef MV_CESA_NO_SRAM
    return (MV_U8*)cesaSramVirtPtr;
#else
    return (MV_U8*)CRYPT_ENG_BASE;
#endif /* MV_CESA_NO_SRAM */
}

MV_ULONG    mvCesaSramVirtToPhys(void* pDev, MV_U8* pSramVirt)
{
#ifdef MV_CESA_NO_SRAM
    return (MV_ULONG)mvOsIoVirtToPhy(NULL, pSramVirt); 
#else
    return (MV_ULONG)pSramVirt;
#endif /* MV_CESA_NO_SRAM */
}

/* Internal Function prototypes */

void        mvCesaSramDescrBuild(int chan, int cacheIdx, MV_U32 config, 
                                 int cryptoOffset, int ivOffset, int cryptoLength,
                                 int macOffset, int digestOffset, int macLength, int macTotalLen);

MV_STATUS   mvCesaCacheSramUpdate(int chan, int sid, MV_DMA_DESC *pIdmaDesc);

int         mvCesaIdmaCopyPrepare(MV_CESA_MBUF* pMbuf, MV_U8* pSramBuf, 
                                MV_DMA_DESC* pIdmaDesc, MV_BOOL isToMbuf,
                                int offset, int copySize);

void        mvCesaHmacIvGet(MV_CESA_MAC_MODE macMode, unsigned char key[], int keyLength, 
                     unsigned char innerIV[], unsigned char outerIV[]);

MV_STATUS   mvCesaFragAuthComplete(MV_CESA_COMMAND* pCmd, MV_CESA_SA* pSA,                            
                               int macDataSize);

MV_CESA_COMMAND*   mvCesaCtrModeInit(void);

MV_STATUS   mvCesaCtrModePrepare(MV_CESA_COMMAND *pCtrModeCmd, MV_CESA_COMMAND *pCmd);
MV_STATUS   mvCesaCtrModeComplete(MV_CESA_COMMAND *pOrgCmd, MV_CESA_COMMAND *pCmd);
void        mvCesaCtrModeFinish(MV_CESA_COMMAND *pCmd);

MV_STATUS   mvCesaCmdProcess(int chan, MV_CESA_COMMAND* pCmd, MV_U8 fixOffset);

MV_STATUS   mvCesaReqProcess(int chan, MV_CESA_REQ* pReq);

MV_STATUS   mvCesaFragReqProcess(MV_CESA_REQ* pReq);

MV_STATUS   mvCesaParamCheck(MV_CESA_SA* pSA, MV_CESA_COMMAND *pCmd, MV_U8* pFixOffset);
MV_STATUS   mvCesaFragParamCheck(MV_CESA_SA* pSA, MV_CESA_COMMAND *pCmd);

void        mvCesaFragSizeFind(MV_CESA_SA* pSA, MV_CESA_COMMAND *pCmd, 
                               int cryptoOffset, int macOffset,
                               int* pCopySize, int* pCryptoDataSize, int* pMacDataSize);


static INLINE MV_CESA_REQ* MV_CESA_REQ_NEXT_PTR(MV_CESA_REQ* pReq)
{
    if(pReq == pCesaReqLast)
        return pCesaReqFirst;

    return pReq+1;
}

/*******************************************************************************
* mvCesaInit - Initialize the CESA driver
*
* DESCRIPTION:
*       This function initialize the CESA driver.
*       1) 
*
* INPUT:
*       int     numOfSession
*       int     queueDepth, 
*       char*   pSramBase
*
* RETURN:
*       MV_STATUS 
*
*******************************************************************************/
MV_STATUS mvCesaInit (int numOfSession, int queueDepth, char* pSramBase)
{
    int     chan, i;
    MV_U32  descOffsetReg, configReg;

/* !!!!
    if(sizeof(MV_CESA_SRAM_MAP) != CRYPT_ENG_SIZE)
    {
        mvOsPrintf("mvCesaInit: Wrong SRAM map\n");
        return MV_FAIL;
    }
*/
    mvOsPrintf("mvCesaInit: sessions=%d, queue=%d, pSram=%p\n",
                numOfSession, queueDepth, pSramBase);

    /* Create Session database */
    pCesaSAD = mvOsMalloc(sizeof(MV_CESA_SA)*numOfSession);
    if(pCesaSAD == NULL)
    {
        mvOsPrintf("CESA Error: Can't allocate %d bytes for %d SAs\n",
                    sizeof(MV_CESA_SA)*numOfSession, numOfSession);
        return MV_NO_RESOURCE;
    }
    memset(pCesaSAD, 0, sizeof(MV_CESA_SA)*numOfSession);
    cesaMaxSA = numOfSession;

    /* Create request queue */
    pCesaReqFirst = mvOsMalloc(sizeof(MV_CESA_REQ)*queueDepth);
    if(pCesaReqFirst == NULL)
    {
        mvOsPrintf("CESA Error: Can't allocate %d bytes for %d requests\n",
                    sizeof(MV_CESA_REQ)*queueDepth, queueDepth);
        return MV_NO_RESOURCE;
    }
    memset(pCesaReqFirst, 0, sizeof(MV_CESA_REQ)*queueDepth);
    pCesaReqEmpty = pCesaReqFirst;
    pCesaReqLast = pCesaReqFirst + (queueDepth-1);
    pCesaReqProcess = pCesaReqEmpty;
    pCesaReqReady = pCesaReqEmpty;
    cesaQueueDepth = queueDepth;
    cesaReqResources = queueDepth;

    /* pSramBase must be 8 byte aligned */
    if( MV_IS_NOT_ALIGN((MV_ULONG)pSramBase, 8) )
    {
        mvOsPrintf("CESA Error: pSramBase (%p) must be 8 byte aligned\n",
                pSramBase);
        return MV_NOT_ALIGNED;
    }
    cesaSramVirtPtr = (MV_CESA_SRAM_MAP*)pSramBase;

    memset(cesaSramVirtPtr, 0, sizeof(MV_CESA_SRAM_MAP));
    for(i=0; i<MV_CESA_MAX_CACHE_SA; i++)
    {
        cesaSramVirtPtr->cacheSA[i].sid = MV_INVALID;
    }

    /* Initialize Channel database and IDMA descriptor lists */
    descOffsetReg = configReg = 0;
    for(chan=0; chan<MV_CESA_MAX_CHAN; chan++)
    {
        int         i;
        MV_ULONG    physAddr;

        pCesaChan[chan].state = MV_CESA_READY;
        pCesaChan[chan].idmaDescBuf.bufSize = sizeof(MV_DMA_DESC)*MV_CESA_MAX_IDMA_DESC + 
                                        CPU_D_CACHE_LINE_SIZE;
        pCesaChan[chan].idmaDescBuf.bufVirtPtr = mvOsIoCachedMalloc(NULL, 
                                        pCesaChan[chan].idmaDescBuf.bufSize, 
                                        &pCesaChan[chan].idmaDescBuf.bufPhysAddr);

        memset(pCesaChan[chan].idmaDescBuf.bufVirtPtr, 0, pCesaChan[chan].idmaDescBuf.bufSize); 

        pCesaChan[chan].pIdmaList = (MV_DMA_DESC*)MV_ALIGN_UP((MV_ULONG)pCesaChan[chan].idmaDescBuf.bufVirtPtr, 
                                                                CPU_D_CACHE_LINE_SIZE);
        physAddr = MV_ALIGN_UP(pCesaChan[chan].idmaDescBuf.bufPhysAddr, CPU_D_CACHE_LINE_SIZE);
        pCesaChan[chan].idmaPhysAddr = physAddr;

        for(i=0; i<MV_CESA_MAX_IDMA_DESC-1; i++)
        {
            /* link all IDMA descriptors together */
            pCesaChan[chan].pIdmaList[i].phyNextDescPtr = MV_32BIT_LE((physAddr + 
                                                            ((i+1)*sizeof(MV_DMA_DESC))));
            mvOsCacheFlush(NULL, &pCesaChan[chan].pIdmaList[i], sizeof(MV_DMA_DESC));        
        }
        pCesaChan[chan].pIdmaList[i].phyNextDescPtr = 0;
        mvOsCacheFlush(NULL, &pCesaChan[chan].pIdmaList[i], sizeof(MV_DMA_DESC));        
        MV_REG_WRITE(IDMA_BYTE_COUNT_REG(chan), 0);
        MV_REG_WRITE(IDMA_CURR_DESC_PTR_REG(chan), 0);
        MV_REG_WRITE(IDMA_CTRL_HIGH_REG(chan), ICCHR_ENDIAN_LITTLE | ICCHR_DESC_BYTE_SWAP_EN);
        MV_REG_WRITE(IDMA_CTRL_LOW_REG(chan), CESA_IDMA_CTRL_LOW_VALUE);

        mvCesaCryptoIvSet(chan, NULL, MV_CESA_MAX_IV_LENGTH);
        pCesaChan[chan].sramBufOffset = (MV_U16)((MV_U8*)cesaSramVirtPtr->buf[chan] - mvCesaSramAddrGet());
        descOffsetReg |= (MV_U16)((MV_U8*)&cesaSramVirtPtr->desc[chan] - mvCesaSramAddrGet());
        MV_REG_WRITE( MV_CESA_CHAN_DESC_OFFSET_REG(chan), descOffsetReg);

        configReg |= MV_CESA_CFG_WAIT_IDMA_MASK(chan);
        configReg |= MV_CESA_CFG_ACT_IDMA_MASK(chan);
    }
    MV_REG_WRITE( IDMA_CAUSE_REG, 0);   

    /* Set CESA configuration registers */
    MV_REG_WRITE( MV_CESA_CFG_REG, configReg);

    /* Initialize LRU cache */
    pCesaCacheLRU = mvLruCacheInit(MV_CESA_MAX_CACHE_SA);
    if(pCesaCacheLRU == NULL)
        return MV_NO_RESOURCE;

    mvCesaDebugStatsClear();

    /* Clear global cesaFrag */
    memset(&cesaFrags, 0, sizeof(MV_CESA_FRAGS));

    return MV_OK;
}

/*******************************************************************************
* mvCesaFinish - Shutdown the CESA driver
*
* DESCRIPTION:
*       This function shutdown the CESA driver and free all allocted resources.
*       1) 
*
* INPUT:
*       int     numOfSession
*       int     queueDepth, 
*       char*   pSramBase
*
* RETURN:
*       MV_STATUS 
*
*******************************************************************************/
MV_STATUS   mvCesaFinish (void)
{
    mvOsPrintf("mvCesaFinish: \n");
    return MV_OK;
}

MV_STATUS   mvCesaCryptoIvSet(int chan, MV_U8* pIV, int ivSize)
{
    MV_U8*  pSramIV = cesaSramVirtPtr->cryptoIV[chan];

    if(ivSize > MV_CESA_MAX_IV_LENGTH)
    {
        mvOsPrintf("mvCesaCryptoIvSet: ivSize (%d) is too large\n", ivSize);
        ivSize = MV_CESA_MAX_IV_LENGTH;
    }
    if(pIV != NULL)
    {
        memcpy(pSramIV, pIV, ivSize);
        ivSize = MV_CESA_MAX_IV_LENGTH - ivSize;
        pSramIV += ivSize;
    }
    
    while(ivSize > 0)
    {
        int size, rand = mvOsRand();

        size = MV_MIN(ivSize, sizeof(rand));
        memcpy(pSramIV, (void*)&rand, size);

        pSramIV += size;
        ivSize -= size;
    }
    mvOsCacheFlush(NULL, cesaSramVirtPtr->cryptoIV[chan], 
                                MV_CESA_MAX_IV_LENGTH);
    mvOsCacheInvalidate(NULL, cesaSramVirtPtr->cryptoIV[chan], 
                              MV_CESA_MAX_IV_LENGTH);

    return MV_OK;                           
}   

MV_STATUS   mvCesaSessionOpen(MV_CESA_OPEN_SESSION *pSession, short* pSid)
{
    short       sid;
    MV_U32      config = 0;
    int         digestSize;

    cesaStats.openedCount++;

    /* Find free entry in SAD */
    for(sid=0; sid<cesaMaxSA; sid++)
    {
        if(pCesaSAD[sid].valid == 0)
        {
            break;
        }
    }
    if(sid == cesaMaxSA)
        return MV_FULL;

    /* Check Input parameters for Open session */
    if (pSession->operation >= MV_CESA_MAX_OPERATION) 
    {
        mvOsPrintf("mvCesaSessionOpen: Unexpected operation %d\n", 
                    pSession->operation);
        return MV_BAD_PARAM;
    }
    config |= (pSession->operation << MV_CESA_OPERATION_OFFSET);

    if( (pSession->direction != MV_CESA_DIR_ENCODE) &&
        (pSession->direction != MV_CESA_DIR_DECODE) )
    {
        mvOsPrintf("mvCesaSessionOpen: Unexpected direction %d\n",
                    pSession->direction);
        return MV_BAD_PARAM;
    }
    config |= (pSession->direction << MV_CESA_DIRECTION_BIT);

    /* Clear SA entry */
    memset(&pCesaSAD[sid], 0, sizeof(pCesaSAD[sid]));

    if(pSession->operation != MV_CESA_CRYPTO_ONLY)
    {
        if(pSession->macKeyLength > MV_CESA_MAX_MAC_KEY_LENGTH)
        {
            mvOsPrintf("mvCesaSessionOpen: macKeyLength %d is too large\n",
                            pSession->macKeyLength);
            return MV_BAD_PARAM;
        }
        switch(pSession->macMode)
        {
            case MV_CESA_MAC_MD5:
            case MV_CESA_MAC_HMAC_MD5:
                digestSize = MV_CESA_MD5_DIGEST_SIZE;
                break;

            case MV_CESA_MAC_SHA1:
            case MV_CESA_MAC_HMAC_SHA1:
                digestSize = MV_CESA_SHA1_DIGEST_SIZE;
                break;

            default:
                mvOsPrintf("mvCesaSessionOpen: Unexpected macMode %d\n",
                            pSession->macMode);
                return MV_BAD_PARAM;
        }
        config |= (pSession->macMode << MV_CESA_MAC_MODE_OFFSET);

        /* Supported digest sizes: MD5 - 16 bytes (128 bits), */
        /* SHA1 - 20 bytes (160 bits) or 12 bytes (96 bits) for both */
        if( (pSession->digestSize != digestSize) && (pSession->digestSize != 12))
        {
            mvOsPrintf("mvCesaSessionOpen: Digest size %d is too large\n",
                        pSession->digestSize);
            return MV_BAD_PARAM;
        }
        pCesaSAD[sid].digestSize = pSession->digestSize;

        if(pCesaSAD[sid].digestSize == 12)
        {
            /* Set MV_CESA_MAC_DIGEST_SIZE_BIT if digest size is 96 bits */
            config |= (MV_CESA_MAC_DIGEST_96B << MV_CESA_MAC_DIGEST_SIZE_BIT);
        }
       
        if( (pSession->macMode == MV_CESA_MAC_HMAC_MD5) || 
            (pSession->macMode == MV_CESA_MAC_HMAC_SHA1) )
        {
            mvCesaHmacIvGet(pSession->macMode, pSession->macKey, pSession->macKeyLength,
                         pCesaSAD[sid].cacheSA.macInnerIV, 
                         pCesaSAD[sid].cacheSA.macOuterIV);
            pCesaSAD[sid].macKeyLength = pSession->macKeyLength;
        }
    }

    if(pSession->operation != MV_CESA_MAC_ONLY)
    {
        switch(pSession->cryptoAlgorithm)
        {
            case MV_CESA_CRYPTO_DES:
                pCesaSAD[sid].cryptoKeyLength = MV_CESA_DES_KEY_LENGTH;                
                pCesaSAD[sid].cryptoBlockSize = MV_CESA_DES_BLOCK_SIZE;
                break;

            case MV_CESA_CRYPTO_3DES:
                pCesaSAD[sid].cryptoKeyLength = MV_CESA_3DES_KEY_LENGTH;  
                pCesaSAD[sid].cryptoBlockSize = MV_CESA_DES_BLOCK_SIZE;
                config |= (MV_CESA_CRYPTO_3DES_EDE << 
                            MV_CESA_CRYPTO_3DES_MODE_BIT);
                break;

            case MV_CESA_CRYPTO_AES:
                switch(pSession->cryptoKeyLength)
                {
                    case 16:
                        pCesaSAD[sid].cryptoKeyLength = MV_CESA_AES_128_KEY_LENGTH;        
                        config |= (MV_CESA_CRYPTO_AES_KEY_128 << 
                                       MV_CESA_CRYPTO_AES_KEY_LEN_OFFSET);
                        break;

                    case 24:
                        pCesaSAD[sid].cryptoKeyLength = MV_CESA_AES_192_KEY_LENGTH;
                        config |= (MV_CESA_CRYPTO_AES_KEY_192 << 
                                       MV_CESA_CRYPTO_AES_KEY_LEN_OFFSET);
                        break;

                    case 32:
                    default:
                        pCesaSAD[sid].cryptoKeyLength = MV_CESA_AES_256_KEY_LENGTH;
                        config |= (MV_CESA_CRYPTO_AES_KEY_256 << 
                                       MV_CESA_CRYPTO_AES_KEY_LEN_OFFSET);
                        break;                                                        
                }                
                pCesaSAD[sid].cryptoBlockSize = MV_CESA_AES_BLOCK_SIZE;
                break;

            default:
                mvOsPrintf("mvCesaSessionOpen: Unexpected cryptoAlgorithm %d\n",
                            pSession->cryptoAlgorithm);
                return MV_BAD_PARAM;
        }
        config |= (pSession->cryptoAlgorithm << MV_CESA_CRYPTO_ALG_OFFSET);

        if(pSession->cryptoKeyLength != pCesaSAD[sid].cryptoKeyLength)
        {
            mvOsPrintf("cesaSessionOpen: Wrong CryptoKeySize %d != %d\n",
                        pSession->cryptoKeyLength, pCesaSAD[sid].cryptoKeyLength);
            return MV_BAD_PARAM;
        }
        /* Copy Crypto key */
        if( (pSession->cryptoAlgorithm == MV_CESA_CRYPTO_AES) &&
            (pSession->direction == MV_CESA_DIR_DECODE))
        {
            aesMakeKey(pCesaSAD[sid].cacheSA.cryptoKey, pSession->cryptoKey, 
                        pSession->cryptoKeyLength*8, MV_CESA_AES_BLOCK_SIZE*8);
        }
        else
        {
            memcpy(pCesaSAD[sid].cacheSA.cryptoKey, pSession->cryptoKey, 
                    pCesaSAD[sid].cryptoKeyLength);
        }

        switch(pSession->cryptoMode)
        {
            case MV_CESA_CRYPTO_ECB:
                pCesaSAD[sid].cryptoIvSize = 0;
                break;

            case MV_CESA_CRYPTO_CBC:
                pCesaSAD[sid].cryptoIvSize = pCesaSAD[sid].cryptoBlockSize;
                break;

            case MV_CESA_CRYPTO_CTR:
                /* Must be Crypto Only */
                if(pSession->operation != MV_CESA_CRYPTO_ONLY)
                {
                    mvOsPrintf("mvCesaSessionOpen: CRYPTO CTR mode can't be mixed with AUTH\n");
                    return MV_BAD_PARAM;
                }
                pCesaSAD[sid].cryptoIvSize = 0;
                pCesaSAD[sid].ctrMode = 1;
                /* Replace to ECB mode for HW */
                pSession->cryptoMode = MV_CESA_CRYPTO_ECB;
                break;

            default:
                mvOsPrintf("mvCesaSessionOpen: Unexpected cryptoMode %d\n",
                            pSession->cryptoMode);
                return MV_BAD_PARAM;
        }
        config |= (pSession->cryptoMode << MV_CESA_CRYPTO_MODE_BIT);
    }
    pCesaSAD[sid].config = config; 

    if(pSid != NULL)
        *pSid = sid;

    pCesaSAD[sid].valid = 1;
    pCesaSAD[sid].cacheIdx = MV_INVALID;
    return MV_OK;
}

MV_STATUS mvCesaSessionClose(short sid)
{
    cesaStats.closedCount++;

    if(sid >= cesaMaxSA)
    {
        mvOsPrintf("CESA Error: sid (%d) is too big\n", sid);
        return MV_BAD_PARAM;
    }
    if(pCesaSAD[sid].valid == 0)
    {
        mvOsPrintf("CESA Warning: Session (sid=%d) is invalid\n", sid);
        return MV_NOT_FOUND;
    }
    if(pCesaSAD[sid].cacheIdx != MV_INVALID)
    {
        /* Delete cache entry */
        mvCesaCacheIdxDelete(pCesaCacheLRU, pCesaSAD[sid].cacheIdx);
        cesaSramVirtPtr->cacheSA[pCesaSAD[sid].cacheIdx].sid = MV_INVALID;
    }

    pCesaSAD[sid].valid = 0;
    return MV_OK;
}

MV_STATUS   mvCesaFragReqProcess(MV_CESA_REQ* pReq)
{
    int                     i, copySize, cryptoDataSize, macDataSize, sid;
    int                     cryptoIvOffset, digestOffset;
    MV_U32                  config;
    MV_CESA_COMMAND*        pCmd = pReq->pCmd;
    MV_CESA_SA*             pSA;
    MV_CESA_MBUF*           pMbuf;
    MV_DMA_DESC*            pIdmaDesc = pCesaChan[0].pIdmaList;
    MV_U8*                  pSramBuf = cesaSramVirtPtr->buf[0];
    int                     macTotalLen = 0;
    int                     fixOffset, cryptoOffset, macOffset;

    pReq->chanId = 0;
    cesaStats.fragCount++;

    sid = pReq->pCmd->sessionId;

    pSA = &pCesaSAD[sid];

    cryptoIvOffset = digestOffset = 0;
    i = 0;

    /* First fragment processing */
    if(pCesaReqProcess->fragMode == MV_CESA_FRAG_FIRST)
    {
        cesaLargeInProc = MV_TRUE;

        pReq->state = MV_CESA_PROCESS;

        cesaFrags.sid = sid;
        cesaFrags.bufOffset = 0;
        cesaFrags.cryptoSize = 0;
        cesaFrags.macSize = 0;

        config = pSA->config | (MV_CESA_FRAG_FIRST << MV_CESA_FRAG_MODE_OFFSET);

        fixOffset = pReq->fixOffset;
        cryptoOffset = pCmd->cryptoOffset;
        macOffset = pCmd->macOffset;

        copySize = sizeof(cesaSramVirtPtr->buf) - pReq->fixOffset;

        /* Find fragment size */
        mvCesaFragSizeFind(pSA, pCmd, cryptoOffset, macOffset, 
                        &copySize, &cryptoDataSize, &macDataSize);

        if( (pSA->config & MV_CESA_OPERATION_MASK) != 
                (MV_CESA_MAC_ONLY << MV_CESA_OPERATION_OFFSET)) 
        {
            /* CryptoIV special processing */
            if( (pSA->config & MV_CESA_CRYPTO_MODE_MASK) == 
                (MV_CESA_CRYPTO_CBC << MV_CESA_CRYPTO_MODE_BIT) )
            {
                /* In CBC mode for encode direction when IV from user */
                if( (pCmd->ivFromUser) &&
                    ((pSA->config & MV_CESA_DIRECTION_MASK) == 
                        (MV_CESA_DIR_ENCODE << MV_CESA_DIRECTION_BIT)) )
                {
                    /* Copy IV from the buffer to SRAM */        
                    mvCesaCopyFromMbuf(cesaSramVirtPtr->cryptoIV[0], 
                               pCmd->pSrc, pCmd->ivOffset, pSA->cryptoIvSize); 
                    mvOsCacheFlush(NULL, cesaSramVirtPtr->cryptoIV[0], 
                                pSA->cryptoIvSize);
                    mvOsCacheInvalidate(NULL, cesaSramVirtPtr->cryptoIV[0], 
                              pSA->cryptoIvSize);
                }

                /* Special processing when IV is not located in the first fragment */
                if(pCmd->ivOffset > (copySize - pSA->cryptoIvSize))
                {
                    /* Prepare dummy place for cryptoIV in SRAM */
                    cryptoIvOffset = cesaSramVirtPtr->tempCryptoIV[0] - mvCesaSramAddrGet();

                    /* For Decryption: Copy IV value from pCmd->ivOffset to Special SRAM place */
                    if((pSA->config & MV_CESA_DIRECTION_MASK) == 
                            (MV_CESA_DIR_DECODE << MV_CESA_DIRECTION_BIT))
                    {
                        mvCesaCopyFromMbuf(cesaSramVirtPtr->tempCryptoIV[0], 
                                   pCmd->pSrc, pCmd->ivOffset, pSA->cryptoIvSize); 
                        mvOsCacheFlush(NULL, cesaSramVirtPtr->tempCryptoIV[0], 
                                    pSA->cryptoIvSize);
                        mvOsCacheInvalidate(NULL, cesaSramVirtPtr->tempCryptoIV[0], 
                                  pSA->cryptoIvSize);
                    }
                    else
                    {
                        /* For Encryption when IV is NOT from User: */
                        /* Copy IV from Chan to buffer (pCmd->ivOffset) */
                        if(pCmd->ivFromUser == 0) 
                        {
                            /* copy IV value from cryptoIV[0] to Buffer (pCmd->ivOffset) */
                            mvCesaCopyToMbuf(cesaSramVirtPtr->cryptoIV[0], 
                                    pCmd->pSrc, pCmd->ivOffset, pSA->cryptoIvSize); 
                        }
                    }
                }
                else
                {
                    cryptoIvOffset = pCmd->ivOffset;
                }
            }
        }

        if( (pSA->config & MV_CESA_OPERATION_MASK) != 
                (MV_CESA_CRYPTO_ONLY << MV_CESA_OPERATION_OFFSET) )
        {
            /* MAC digest special processing on Decode direction */
            if((pSA->config & MV_CESA_DIRECTION_MASK) == 
                        (MV_CESA_DIR_DECODE << MV_CESA_DIRECTION_BIT))
            {
                /* Save digest from pCmd->digestOffset */
                mvCesaCopyFromMbuf(cesaFrags.orgDigest, 
                               pCmd->pSrc, pCmd->digestOffset, pSA->digestSize); 

                /* If pCmd->digestOffset is not located on the first */
                if(pCmd->digestOffset > (copySize - pSA->digestSize))
                {
                    MV_U8  digestZero[MV_CESA_MAX_DIGEST_SIZE];

                    /* Set zeros to pCmd->digestOffset (DRAM) */
                    memset(digestZero, 0, MV_CESA_MAX_DIGEST_SIZE);
                    mvCesaCopyToMbuf(digestZero, pCmd->pSrc, pCmd->digestOffset, pSA->digestSize);

                    /* Prepare dummy place for digest in SRAM */
                    digestOffset = cesaSramVirtPtr->tempDigest[0] - mvCesaSramAddrGet();
                }
                else
                {
                    digestOffset = pCmd->digestOffset;
                }
            }
        }
        /* Update cache if nessesary */
        if( mvCesaCacheSramUpdate(0, sid, &pIdmaDesc[i]) == MV_OK)
        {
            i++;
        }
        pCesaReqProcess->fragMode = MV_CESA_FRAG_MIDDLE;
    }
    else
    {
        /* Continue fragment */
        fixOffset = 0;
        cryptoOffset = 0;
        macOffset = 0;
        if( (pCmd->pSrc->mbufSize - cesaFrags.bufOffset) <= sizeof(cesaSramVirtPtr->buf))
        {
            /* Last fragment */
            config = pSA->config | (MV_CESA_FRAG_LAST << MV_CESA_FRAG_MODE_OFFSET);
            pCesaReqProcess->fragMode = MV_CESA_FRAG_LAST;
            copySize = pCmd->pSrc->mbufSize - cesaFrags.bufOffset;

            if( (pSA->config & MV_CESA_OPERATION_MASK) != 
                (MV_CESA_CRYPTO_ONLY << MV_CESA_OPERATION_OFFSET) )
            {
                macDataSize = pCmd->macLength - cesaFrags.macSize;

                /* If pCmd->digestOffset is not located on last fragment */
                if(pCmd->digestOffset < cesaFrags.bufOffset)
                {
                    /* Prepare dummy place for digest in SRAM */                
                    digestOffset = cesaSramVirtPtr->tempDigest[0] - mvCesaSramAddrGet();
                }
                else
                {
                    digestOffset = pCmd->digestOffset - cesaFrags.bufOffset;
                }
                cesaFrags.newDigestOffset = digestOffset;
                macTotalLen = pCmd->macLength;

#ifdef MV_CESA_FRAGS_WA
                {
                    /* Calculate Last block by SW */
                    mvCesaFragAuthComplete(pCmd, pSA, macDataSize);
                    /* */
                    cesaChanReadyMap |= (1 << 0);

                    return MV_TERMINATE;
                }
#endif /* MV_CESA_FRAGS_WA */
            }
            if( (pSA->config & MV_CESA_OPERATION_MASK) != 
                (MV_CESA_MAC_ONLY << MV_CESA_OPERATION_OFFSET) )
            {
                cryptoDataSize = pCmd->cryptoLength - cesaFrags.cryptoSize;
            }

            /* cryptoIvOffset - don't care */
        }
        else
        {
            /* Middle fragment */
            config = pSA->config | (MV_CESA_FRAG_MIDDLE << MV_CESA_FRAG_MODE_OFFSET);
            copySize = sizeof(cesaSramVirtPtr->buf);
            /* digestOffset and cryptoIvOffset - don't care */

            /* Find fragment size */
            mvCesaFragSizeFind(pSA, pCmd, cryptoOffset, macOffset,
                            &copySize, &cryptoDataSize, &macDataSize);
        }
    }
    /********* Prepare IDMA descriptors to copy from pSrc to SRAM *********/
    pMbuf = pCmd->pSrc;
    i += mvCesaIdmaCopyPrepare(pMbuf, pSramBuf + fixOffset, &pIdmaDesc[i], 
                                MV_FALSE, cesaFrags.bufOffset, copySize);

   /* Add special descriptor Ownership for CPU */ 
    pIdmaDesc[i].byteCnt = 0;
    pIdmaDesc[i].phySrcAdd = 0;
    pIdmaDesc[i].phyDestAdd = 0;
    pIdmaDesc[i].phyNextDescPtr = MV_32BIT_LE((pCesaChan[0].idmaPhysAddr + 
                                                ((i+1)*sizeof(MV_DMA_DESC))));
    mvOsCacheFlush(NULL, &pIdmaDesc[i], sizeof(MV_DMA_DESC));
    i++;

    /********* Prepare IDMA descriptors to copy from SRAM to pDst *********/
    pMbuf = pCmd->pDst;
    i += mvCesaIdmaCopyPrepare(pMbuf, pSramBuf + fixOffset, &pIdmaDesc[i], 
                                MV_TRUE, cesaFrags.bufOffset, copySize);

    /* Next field of Last Idma descriptor must be NULL */
    pIdmaDesc[i-1].phyNextDescPtr = 0;
    mvOsCacheFlush(NULL, &pIdmaDesc[i-1], sizeof(MV_DMA_DESC));

    /* Update fragmentation mode */
    mvCesaSramDescrBuild(0, pSA->cacheIdx, config, 
                cryptoOffset + fixOffset, cryptoIvOffset + fixOffset, 
                cryptoDataSize, macOffset + fixOffset, 
                digestOffset + fixOffset, macDataSize, macTotalLen);

    cesaFrags.bufOffset += copySize;
    cesaFrags.cryptoSize += cryptoDataSize;
    cesaFrags.macSize += macDataSize;

    pCesaChan[0].state = MV_CESA_PROCESS;

    /* Enable IDMA engine */
    MV_REG_WRITE(IDMA_CURR_DESC_PTR_REG(0), 0);
    MV_REG_WRITE(IDMA_CAUSE_REG, 0);
    MV_REG_WRITE(IDMA_NEXT_DESC_PTR_REG(0), (MV_U32)pCesaChan[0].idmaPhysAddr);

    /* Start Accelerator */
    MV_REG_WRITE(MV_CESA_CMD_REG, MV_CESA_CMD_CHAN_ENABLE_MASK(0));
    return MV_OK;
}

MV_STATUS   mvCesaReqProcess(int chan, MV_CESA_REQ* pReq)
{
    MV_STATUS   status;

    cesaStats.procCount[chan]++;

    pReq->chanId = chan;
    pReq->state = MV_CESA_PROCESS;

    if(pReq->pCmd->pSrc->mbufSize > sizeof(cesaSramVirtPtr->buf[0]) )
    {
        cesaStats.largeCount++;
        cesaLargeInProc = MV_TRUE;
    }

    /* Pass request to HW */
    status = mvCesaCmdProcess(chan, pReq->pCmd, pReq->fixOffset);
    if(status != MV_OK)
    {
        mvOsPrintf("mvCesaCmdProcess Failed: chan=%d, status=0x%x\n", 
                     chan, status);
        return status;
    }
    
    pCesaChan[chan].state = MV_CESA_PROCESS;
    return MV_OK;
}

MV_STATUS mvCesaAction (MV_CESA_COMMAND *pCmd)
{
    MV_STATUS       status;
    MV_CESA_REQ*    pReq = pCesaReqEmpty;
    int             chan;
    int             sid = pCmd->sessionId;
    MV_CESA_SA*     pSA = &pCesaSAD[sid];

    if(cesaReqResources == 0)
        return MV_NO_RESOURCE;

    cesaStats.reqCount++;

    if(pSA->ctrMode)
    {
        pReq->pOrgCmd = pCmd;
        pCmd = mvCesaCtrModeInit();
        if(pCmd == NULL)
            return MV_OUT_OF_CPU_MEM;

        mvCesaCtrModePrepare(pCmd, pReq->pOrgCmd);
        pReq->fixOffset = 0;
    }
    else
    {
        status = mvCesaParamCheck(pSA, pCmd, &pReq->fixOffset);
        if(status != MV_OK)
        {
            return status;
        }
    }

    /* Check if the packet need small buffer, large buffer of fragmentation */
    if(pCmd->pSrc->mbufSize <= sizeof(cesaSramVirtPtr->buf[0]) )
    {
        pReq->fragMode = MV_CESA_FRAG_NONE;
    }
    else if(pCmd->pSrc->mbufSize <= sizeof(cesaSramVirtPtr->buf))
    {
        pReq->fragMode = MV_CESA_FRAG_NONE;
    }
    else
    {
        /* Check restrictions for fragmented packets processing */
        status = mvCesaFragParamCheck(pSA, pCmd);
        if(status != MV_OK)
            return status;

        pReq->fragMode = MV_CESA_FRAG_FIRST;        
    }

    pReq->pCmd = pCmd;

    pReq->state = MV_CESA_PENDING;
            
    pCesaReqEmpty = MV_CESA_REQ_NEXT_PTR(pReq);
    cesaReqResources -= 1;

    if( (cesaQueueDepth - cesaReqResources) > cesaStats.maxReqCount)
        cesaStats.maxReqCount = (cesaQueueDepth - cesaReqResources);

    /* Check status of CESA channels and process requests */
    pReq = pCesaReqProcess;
    for(chan=0; chan<MV_CESA_MAX_CHAN; chan++)
    {
        if( (pReq == pCesaReqEmpty) || (cesaLargeInProc == MV_TRUE) )
        {
            /* No requests to process or Large request in process */
            break;
        }
        /* If next request is Large one wait until both channels are ready */
        if( (pReq->pCmd->pSrc->mbufSize > sizeof(cesaSramVirtPtr->buf[0])) &&
            (pCesaReqProcess != pCesaReqReady) )
        {
            break;
        }

        if(pCesaChan[chan].state == MV_CESA_READY)
        {
            if(pReq->fragMode == MV_CESA_FRAG_NONE)
            {
                status = mvCesaReqProcess(chan, pReq);
                if(status != MV_OK)
                {
                    mvOsPrintf("CesaReady: ReqProcess error: chan=%d, pReq=%p, status=0x%x\n",
                            chan, pReq, status);
                }
                pReq = MV_CESA_REQ_NEXT_PTR(pReq);        
            }
            else
            {
                status = mvCesaFragReqProcess(pReq);
                if(status != MV_OK)
                {
                    mvOsPrintf("CesaReady: FragReqProcess error: chan=%d, pReq=%p, status=0x%x\n",
                                chan, pReq, status);
                }
                if(pReq->fragMode == MV_CESA_FRAG_LAST)
                    pReq = MV_CESA_REQ_NEXT_PTR(pReq);        
            }
        }
    }
    pCesaReqProcess = pReq;
    if(cesaReqResources == 0)
        return MV_NO_MORE;

    return MV_OK;
}

MV_U32  mvCesaChanInProcessGet(void)
{
    int     chan;
    MV_U32  chanMap = 0;

    for(chan=0; chan<MV_CESA_MAX_CHAN; chan++)
    {
        if(pCesaChan[chan].state == MV_CESA_PROCESS)
        {
            chanMap |= (1 << chan);
        }
    }
    return chanMap;
}

MV_BOOL     mvCesaIsReady(int chan)
{
    return MV_TRUE;
}

MV_STATUS   mvCesaReadyDispatch(MV_U32 chanMask)
{
    return MV_OK;
}

MV_STATUS mvCesaReadyGet(MV_U32 chanMap, MV_CESA_RESULT* pResult)
{
    MV_STATUS       status, readyStatus = MV_NOT_READY;
    int             chan;
    MV_U32          statusReg;
    MV_CESA_REQ*    pReq;
    MV_CESA_SA*     pSA;

    cesaChanReadyMap |= chanMap;
    if( (pCesaReqReady == pCesaReqProcess) &&
        (pCesaReqReady->state != MV_CESA_PROCESS) )
    {
        if(cesaChanReadyMap)
        {
            mvOsPrintf("Cesa wrong empty\n");
        }
        return MV_EMPTY;
    }
    chan = pCesaReqReady->chanId;

    if( (cesaChanReadyMap & (1 << chan)) == 0)
    {
/*
        mvOsPrintf("Cesa Not ready: cesaChanReadyMap=%d, chan=%d\n",
                            cesaChanReadyMap, chan);
*/
        cesaStats.notReadyCount[chan]++;
        return MV_NOT_READY;
    }
    cesaStats.readyCount[chan]++;

    pReq = pCesaReqReady;
    pSA = &pCesaSAD[pReq->pCmd->sessionId]; 

#ifdef CESA_DEBUG
    statusReg = MV_REG_READ(MV_CESA_STATUS_REG);
    if( statusReg & MV_CESA_STATUS_ACTIVE_MASK(chan) )
    {
        mvOsPrintf("mvCesaReadyGet - %d: CESA Status = 0x%x\n", chan, statusReg);
        return MV_NOT_READY;
    }
#endif /* CESA_DEBUG */

    /* Clear ready map */
    cesaChanReadyMap &= ~(1 << chan);

    pResult->retCode = MV_OK;
    if(pReq->fragMode != MV_CESA_FRAG_NONE)
    {
        MV_U8*          pNewDigest;

        /* Process fragmented packet */
        if(pReq->fragMode == MV_CESA_FRAG_LAST)
        {
            /* Fragmented packet is ready */
            if( (pSA->config & MV_CESA_OPERATION_MASK) != 
                (MV_CESA_CRYPTO_ONLY << MV_CESA_OPERATION_OFFSET) )
            {

                /* Copy new digest from SRAM to the Destination buffer */
                pNewDigest = mvCesaSramAddrGet() + pCesaChan[chan].sramBufOffset + 
                                               cesaFrags.newDigestOffset;
                status = mvCesaCopyToMbuf(pNewDigest, pReq->pCmd->pDst, 
                                   pReq->pCmd->digestOffset, pSA->digestSize);

                /* For decryption: Compare new digest value with original one */
                if((pSA->config & MV_CESA_DIRECTION_MASK) == 
                            (MV_CESA_DIR_DECODE << MV_CESA_DIRECTION_BIT))
                {
                    if( memcmp(pNewDigest, cesaFrags.orgDigest, pSA->digestSize) != 0)
                    {
/*
                        mvOsPrintf("Digest error: chan=%d, newDigest=%p, orgDigest=%p, status = 0x%x\n", 
                            chan, pNewDigest, cesaFrags.orgDigest, MV_REG_READ(MV_CESA_STATUS_REG));
*/
                        pResult->retCode = MV_FAIL;
                    }
                }
            }
            cesaLargeInProc = MV_FALSE;
            readyStatus = MV_OK;
        }
    }
    else
    {
        if( ((pSA->config & MV_CESA_OPERATION_MASK) != 
                (MV_CESA_CRYPTO_ONLY << MV_CESA_OPERATION_OFFSET) ) &&
            ((pSA->config & MV_CESA_DIRECTION_MASK) == 
                        (MV_CESA_DIR_DECODE << MV_CESA_DIRECTION_BIT)) )
        {
            /* For decryption Check Digest error */
            statusReg = MV_REG_READ(MV_CESA_STATUS_REG);
            if( statusReg & MV_CESA_STATUS_DIGEST_ERR_MASK(chan) )
            {
/*
                mvOsPrintf("Digest error: chan=%d, status = 0x%x\n", 
                        chan, statusReg);
*/
                pResult->retCode = MV_FAIL;
            }
        }
        readyStatus = MV_OK;
        cesaLargeInProc = MV_FALSE;
    }
    pCesaChan[chan].state = MV_CESA_READY;

    if(readyStatus == MV_OK)
    {
        pResult->pReqPrv = pReq->pCmd->pReqPrv;
        pResult->sessionId = pReq->pCmd->sessionId;

        pReq->state = MV_CESA_IDLE;
        pCesaReqReady = MV_CESA_REQ_NEXT_PTR(pReq);
        cesaReqResources++;

        if(pSA->ctrMode)
        {
            mvCesaCtrModeComplete(pReq->pOrgCmd, pReq->pCmd);
            mvCesaCtrModeFinish(pReq->pCmd);
            pReq->pOrgCmd = NULL;
        }
    }

    /* Process next request from the queue if possible */
    if( (pCesaReqProcess != pCesaReqEmpty) || 
        (pCesaReqProcess->state == MV_CESA_PROCESS) )
    {
        if(pCesaReqProcess->fragMode == MV_CESA_FRAG_NONE)
        {
            status = mvCesaReqProcess(chan, pCesaReqProcess);
            if(status != MV_OK)
            {
                mvOsPrintf("CesaReady: ReqProcess error: chan=%d, pReq=%p, status=0x%x\n",
                            chan, pCesaReqProcess, status);
            }
            pCesaReqProcess = MV_CESA_REQ_NEXT_PTR(pCesaReqProcess);        
        }
        else
        {
            status = mvCesaFragReqProcess(pCesaReqProcess);
            if(status == MV_OK)
            {
                /* Replace MV_NOT_READY with MV_BUSY for fragmented packets */
                if(readyStatus == MV_NOT_READY)
                    readyStatus = MV_BUSY;
            }
            else if(status == MV_TERMINATE)
            {
                readyStatus = status;
            }
            else
            {
                mvOsPrintf("CesaReady: FragReqProcess error: chan=%d, pReq=%p, status=0x%x\n",
                            chan, pCesaReqProcess, status);
                pCesaReqProcess->fragMode = MV_CESA_FRAG_LAST;
            }
            /* If fragmented packet processing is finished go to next */
            if(pCesaReqProcess->fragMode == MV_CESA_FRAG_LAST)
            {
                pCesaReqProcess = MV_CESA_REQ_NEXT_PTR(pCesaReqProcess);        
            }
        }
    }
    return readyStatus;
}


/* INTERNAL FUNCTIONS */

MV_STATUS   mvCesaCmdProcess(int chan, MV_CESA_COMMAND* pCmd, MV_U8 fixOffset)
{
    MV_CESA_MBUF    *pMbuf;
    MV_DMA_DESC     *pIdmaDesc;
    MV_U8           *pSramBuf;
    int             sid, i, cacheIdx;
    MV_CESA_SA      *pSA; 

    sid = pCmd->sessionId;
    pSA = &pCesaSAD[sid];
    pIdmaDesc = pCesaChan[chan].pIdmaList;
    pSramBuf = cesaSramVirtPtr->buf[chan];

/*
    mvOsPrintf("CesaCmdProcess: chan=%d, sid=%d, pSA=%p, pIdmaDesc=%p, pSramBuf=%p\n",
                chan, sid, pSA, pIdmaDesc, pSramBuf);
*/
    /* Special processing for IV in CRYPTO CBC mode Encryption mode */
    if( ((pSA->config & MV_CESA_OPERATION_MASK) != (MV_CESA_MAC_ONLY << MV_CESA_OPERATION_OFFSET)) &&
        ((pSA->config & MV_CESA_CRYPTO_MODE_MASK) == (MV_CESA_CRYPTO_CBC << MV_CESA_CRYPTO_MODE_BIT)) &&
        ((pSA->config & MV_CESA_DIRECTION_MASK) == (MV_CESA_DIR_ENCODE << MV_CESA_DIRECTION_BIT)) &&
        (pCmd->ivFromUser) )
    {
        /* Copy IV from the buffer to SRAM */        
        mvCesaCopyFromMbuf(cesaSramVirtPtr->cryptoIV[chan], 
                           pCmd->pSrc, pCmd->ivOffset, pSA->cryptoIvSize); 
        mvOsCacheFlush(NULL, cesaSramVirtPtr->cryptoIV[chan], 
                            pSA->cryptoIvSize);
        mvOsCacheInvalidate(NULL, cesaSramVirtPtr->cryptoIV[chan], 
                          pSA->cryptoIvSize);
    }

    /* Update cache if nessesary */
    i = 0;
    if( mvCesaCacheSramUpdate(chan, sid, &pIdmaDesc[i]) == MV_OK)
    {
        i++;
    }
    cacheIdx = pSA->cacheIdx;

    /********* Prepare IDMA descriptors to copy from pSrc to SRAM *********/
    pMbuf = pCmd->pSrc;
    i += mvCesaIdmaCopyPrepare(pMbuf, pSramBuf + fixOffset, &pIdmaDesc[i], 
                                MV_FALSE, 0, pMbuf->mbufSize);

   /* Add special descriptor Ownership for CPU */ 
    pIdmaDesc[i].byteCnt = 0;
    pIdmaDesc[i].phySrcAdd = 0;
    pIdmaDesc[i].phyDestAdd = 0;
    pIdmaDesc[i].phyNextDescPtr = MV_32BIT_LE((pCesaChan[chan].idmaPhysAddr + 
                                                ((i+1)*sizeof(MV_DMA_DESC))));
    mvOsCacheFlush(NULL, &pIdmaDesc[i], sizeof(MV_DMA_DESC));
    i++;

    /********* Prepare IDMA descriptors to copy from SRAM to pDst *********/
    pMbuf = pCmd->pDst;
    i += mvCesaIdmaCopyPrepare(pMbuf, pSramBuf + fixOffset, &pIdmaDesc[i], 
                                MV_TRUE, 0, pMbuf->mbufSize);

    /* Next field of Last Idma descriptor must be NULL */
    pIdmaDesc[i-1].phyNextDescPtr = 0;
    mvOsCacheFlush(NULL, &pIdmaDesc[i-1], sizeof(MV_DMA_DESC));
            
    /* Write Security Accelerator descriptor to SRAM words 0 - 7 */
    mvCesaSramDescrBuild(chan, cacheIdx, pSA->config, pCmd->cryptoOffset + fixOffset, 
                        pCmd->ivOffset + fixOffset, pCmd->cryptoLength,
                        pCmd->macOffset + fixOffset, pCmd->digestOffset + fixOffset, 
                        pCmd->macLength, pCmd->macLength);

    /* Enable IDMA engine */
    MV_REG_WRITE(IDMA_CURR_DESC_PTR_REG(chan), 0);
    MV_REG_WRITE(IDMA_CAUSE_REG, 0);
    MV_REG_WRITE(IDMA_NEXT_DESC_PTR_REG(chan), (MV_U32)pCesaChan[chan].idmaPhysAddr);

    /* Start Accelerator */
    MV_REG_WRITE(MV_CESA_CMD_REG, MV_CESA_CMD_CHAN_ENABLE_MASK(chan));

    return MV_OK;
}


/* Functions to work with CESA_MBUF structure */

int     mvCesaMbufOffset(MV_CESA_MBUF* pMbuf, int offset, int* pBufOffset)
{
    int frag = 0;

    while(offset > 0)
    {
        if(frag >= pMbuf->numFrags)
        {
            mvOsPrintf("mvCesaMbufOffset: Error: frag (%d) > numFrags (%d)\n",
                    frag, pMbuf->numFrags);
            return MV_INVALID;
        }
        if(offset < pMbuf->pFrags[frag].bufSize)
        {
            break;
        }
        offset -= pMbuf->pFrags[frag].bufSize;
        frag++;                
    }
    if(pBufOffset != NULL)
        *pBufOffset = offset;

    return frag;
}

MV_STATUS   mvCesaCopyFromMbuf(MV_U8* pDstBuf, MV_CESA_MBUF* pSrcMbuf, 
                               int offset, int size)
{
    int     frag, fragOffset, bufSize;
    MV_U8*  pBuf;

    if((offset+size) > pSrcMbuf->mbufSize)
    {
        mvOsPrintf("cesaMbuf Error: offset(%d)+size(%d) > mbufSize(%d)\n",
                    offset, size, pSrcMbuf->mbufSize);
        return MV_INVALID;
    }

    frag = mvCesaMbufOffset(pSrcMbuf, offset, &fragOffset);
    if(frag == MV_INVALID)
    {
        mvOsPrintf("CESA Mbuf Error: offset (%d) out of range\n", offset);
        return MV_OUT_OF_RANGE;
    }

    bufSize = pSrcMbuf->pFrags[frag].bufSize - fragOffset;
    pBuf = pSrcMbuf->pFrags[frag].bufVirtPtr + fragOffset;
    while(MV_TRUE)
    {
        if(size <= bufSize)
        {
            memcpy(pDstBuf, pBuf, size);
            return MV_OK;
        }
        memcpy(pDstBuf, pBuf, bufSize);      
        size -= bufSize;
        frag++;
        if(frag >= pSrcMbuf->numFrags)
            break;

        bufSize = pSrcMbuf->pFrags[frag].bufSize;
        pBuf = pSrcMbuf->pFrags[frag].bufVirtPtr;
    }
    mvOsPrintf("mvCesaCopyFromMbuf: Mbuf is EMPTY - %d bytes isn't copied\n",
                size);
    return MV_EMPTY;
}

MV_STATUS   mvCesaCopyToMbuf(MV_U8* pSrcBuf, MV_CESA_MBUF* pDstMbuf, 
                               int offset, int size)
{
    int     frag, fragOffset, bufSize;
    MV_U8*  pBuf;

    frag = mvCesaMbufOffset(pDstMbuf, offset, &fragOffset);
    if(frag == MV_INVALID)
    {
        mvOsPrintf("CESA Mbuf Error: offset (%d) out of range\n", offset);
        return MV_OUT_OF_RANGE;
    }

    bufSize = pDstMbuf->pFrags[frag].bufSize - fragOffset;
    pBuf = pDstMbuf->pFrags[frag].bufVirtPtr + fragOffset;
    while(MV_TRUE)
    {
        if(size <= bufSize)
        {
            memcpy(pBuf, pSrcBuf, size);
            return MV_OK;
        }
        memcpy(pBuf, pSrcBuf, bufSize);
        size -= bufSize;
        frag++;
        if(frag >= pDstMbuf->numFrags)
            break;

        bufSize = pDstMbuf->pFrags[frag].bufSize;
        pBuf = pDstMbuf->pFrags[frag].bufVirtPtr;
    }
    mvOsPrintf("mvCesaCopyToMbuf: Mbuf is FULL - %d bytes isn't copied\n",
                size);
    return MV_FULL;
}

MV_STATUS   mvCesaMbufCopy(MV_CESA_MBUF* pMbufDst, int dstOffset, 
                           MV_CESA_MBUF* pMbufSrc, int srcOffset, int size)
{
    return MV_OK;
}


void    mvCesaSramDescrBuild(int chan, int cacheIdx, MV_U32 config, 
                             int cryptoOffset, int ivOffset, int cryptoLength,
                             int macOffset, int digestOffset, int macLength, 
                             int macTotalLen)
{
    MV_CESA_DESC    *pCesaDesc;

    pCesaDesc = &cesaSramVirtPtr->desc[chan];

    pCesaDesc->config = config;

    if( (config & MV_CESA_OPERATION_MASK) != 
         (MV_CESA_MAC_ONLY << MV_CESA_OPERATION_OFFSET) )
    {
        /* word 1 */    
        pCesaDesc->cryptoSrcOffset = pCesaChan[chan].sramBufOffset + cryptoOffset;
        pCesaDesc->cryptoDstOffset = pCesaChan[chan].sramBufOffset + cryptoOffset;
        /* word 2 */    
        pCesaDesc->cryptoDataLen = cryptoLength;
        /* word 3 */
        pCesaDesc->cryptoKeyOffset = (MV_U16)(cesaSramVirtPtr->cacheSA[cacheIdx].cryptoKey - 
                                                            mvCesaSramAddrGet());
        /* word 4 */
        pCesaDesc->cryptoIvOffset  = (MV_U16)(cesaSramVirtPtr->cryptoIV[chan] - 
                                                            mvCesaSramAddrGet());
        pCesaDesc->cryptoIvBufOffset = pCesaChan[chan].sramBufOffset + ivOffset;
    }

    if( (config & MV_CESA_OPERATION_MASK) != 
         (MV_CESA_CRYPTO_ONLY << MV_CESA_OPERATION_OFFSET) )
    {
        /* word 5 */
        pCesaDesc->macSrcOffset = pCesaChan[chan].sramBufOffset + macOffset;
        pCesaDesc->macTotalLen = macTotalLen;

        /* word 6 */
        pCesaDesc->macDigestOffset = pCesaChan[chan].sramBufOffset + digestOffset;
        pCesaDesc->macDataLen = macLength;

        /* word 7 */
        pCesaDesc->macInnerIvOffset = (MV_U16)(cesaSramVirtPtr->cacheSA[cacheIdx].macInnerIV - 
                                                            mvCesaSramAddrGet());
        pCesaDesc->macOuterIvOffset = (MV_U16)(cesaSramVirtPtr->cacheSA[cacheIdx].macOuterIV - 
                                                            mvCesaSramAddrGet());
    }
    /* Flush Descriptor in SRAM if SRAM is cached */
    mvOsCacheFlush(NULL, &cesaSramVirtPtr->desc[chan], sizeof(MV_CESA_DESC));
}

MV_STATUS   mvCesaCacheSramUpdate(int chan, int sid, MV_DMA_DESC *pIdmaDesc)
{
    int             oldSid;
    MV_STATUS       status = MV_NO_CHANGE;
    MV_CESA_SA      *pSA = &pCesaSAD[sid];

    if(pSA->cacheIdx == MV_INVALID)
    {
        status = MV_OK;

        pSA->cacheIdx = mvCesaCacheIdxFind(pCesaCacheLRU);
        /* Update old SA entry used this cache entry */
        oldSid = cesaSramVirtPtr->cacheSA[pSA->cacheIdx].sid;
        if(oldSid != MV_INVALID)
        {                
            pCesaSAD[oldSid].cacheIdx = MV_INVALID;
        }
        pSA->cacheSA.sid = sid;

        /* Copy CACHE_SA to SRAM if needed */
        pIdmaDesc->byteCnt = MV_32BIT_LE(sizeof(MV_CESA_CACHE_SA) | BIT31);
        pIdmaDesc->phySrcAdd = MV_32BIT_LE(mvOsIoVirtToPhy(NULL, &pSA->cacheSA));
        pIdmaDesc->phyDestAdd = 
             MV_32BIT_LE(mvCesaSramVirtToPhys(NULL, (MV_U8*)&cesaSramVirtPtr->cacheSA[pSA->cacheIdx]));
                                    
        pIdmaDesc->phyNextDescPtr = MV_32BIT_LE(mvOsIoVirtToPhy(NULL, &pIdmaDesc[1]) );

        /* flush Source buffer */
        mvOsCacheFlush(NULL, &pSA->cacheSA, sizeof(MV_CESA_CACHE_SA));
        /* Invalidate destination buffer (SRAM)   */
        mvOsCacheInvalidate(NULL, &cesaSramVirtPtr->cacheSA[pSA->cacheIdx], 
                        sizeof(MV_CESA_CACHE_SA));
        /* flush the Idma desc */
        mvOsCacheFlush(NULL, pIdmaDesc, sizeof(MV_DMA_DESC));        
    }
    mvCesaCacheIdxUpdate(pCesaCacheLRU, pSA->cacheIdx);
    return status;
}

int    mvCesaIdmaCopyPrepare(MV_CESA_MBUF* pMbuf, MV_U8* pSramBuf, 
                        MV_DMA_DESC* pIdmaDesc, MV_BOOL isToMbuf,
                        int offset, int copySize)
{
    int     bufOffset, bufSize, size, frag, i;
    MV_U8*  pBuf;
    
    i = 0;

    frag = mvCesaMbufOffset(pMbuf, offset, &bufOffset);
    bufSize = pMbuf->pFrags[frag].bufSize - bufOffset;
    pBuf = pMbuf->pFrags[frag].bufVirtPtr + bufOffset;

    /* Create IDMA lists to copy mBuf from pSrc to SRAM */
    size = 0;
    while(size < copySize)
    {
        bufSize = MV_MIN(bufSize, (copySize - size));
        pIdmaDesc[i].byteCnt = MV_32BIT_LE(bufSize | BIT31);
        if(isToMbuf)
        {
            pIdmaDesc[i].phyDestAdd = MV_32BIT_LE(mvOsIoVirtToPhy(NULL, pBuf));
            pIdmaDesc[i].phySrcAdd  = 
                MV_32BIT_LE(mvCesaSramVirtToPhys(NULL, (pSramBuf + size)));
            /* invalidate the buffer */
            mvOsCacheInvalidate(NULL, pBuf, bufSize);
        }
        else
        {
            pIdmaDesc[i].phySrcAdd = MV_32BIT_LE(mvOsIoVirtToPhy(NULL, pBuf));
            pIdmaDesc[i].phyDestAdd = 
                MV_32BIT_LE(mvCesaSramVirtToPhys(NULL, (pSramBuf + size)));
            /* flush the buffer */
            mvOsCacheFlush(NULL, pBuf, bufSize);
        }
        pIdmaDesc[i].phyNextDescPtr = MV_32BIT_LE(mvOsIoVirtToPhy(NULL, (&pIdmaDesc[i+1])) );

        /* flush the Idma desc */
        mvOsCacheFlush(NULL, &pIdmaDesc[i], sizeof(MV_DMA_DESC));
        i++;
        frag++;
        size += bufSize;
        pBuf = pMbuf->pFrags[frag].bufVirtPtr;
        bufSize = pMbuf->pFrags[frag].bufSize;
    }
    return i;
}

void    mvCesaHmacIvGet(MV_CESA_MAC_MODE macMode, unsigned char key[], int keyLength, 
                     unsigned char innerIV[], unsigned char outerIV[])
{
    unsigned char   inner[MV_CESA_MAX_MAC_KEY_LENGTH]; 
    unsigned char   outer[MV_CESA_MAX_MAC_KEY_LENGTH];
    int             i, digestSize = 0;
    MV_U32          swapped32, val32, *pVal32;
 
    for(i=0; i<keyLength; i++)
    {
        inner[i] = 0x36 ^ key[i];
        outer[i] = 0x5c ^ key[i];
    }

    for(i=keyLength; i<MV_CESA_MAX_MAC_KEY_LENGTH; i++)
    {
        inner[i] = 0x36;
        outer[i] = 0x5c;
    }
    if(macMode == MV_CESA_MAC_HMAC_MD5)
    {
        MV_MD5_CONTEXT  ctx;

        mvMD5Init(&ctx);
        mvMD5Update(&ctx, inner, MV_CESA_MAX_MAC_KEY_LENGTH);

        memcpy(innerIV, ctx.buf, MV_CESA_MD5_DIGEST_SIZE);
        memset(&ctx, 0, sizeof(ctx));

        mvMD5Init(&ctx);
        mvMD5Update(&ctx, outer, MV_CESA_MAX_MAC_KEY_LENGTH);
        memcpy(outerIV, ctx.buf, MV_CESA_MD5_DIGEST_SIZE);
        memset(&ctx, 0, sizeof(ctx));
        digestSize = MV_CESA_MD5_DIGEST_SIZE;
    }
    else if(macMode == MV_CESA_MAC_HMAC_SHA1)
    {
        MV_SHA1_CTX  ctx;

        mvSHA1Init(&ctx);
        mvSHA1Update(&ctx, inner, MV_CESA_MAX_MAC_KEY_LENGTH);
        memcpy(innerIV, ctx.state, MV_CESA_SHA1_DIGEST_SIZE);
        memset(&ctx, 0, sizeof(ctx));

        mvSHA1Init(&ctx);
        mvSHA1Update(&ctx, outer, MV_CESA_MAX_MAC_KEY_LENGTH);
        memcpy(outerIV, ctx.state, MV_CESA_SHA1_DIGEST_SIZE);
        memset(&ctx, 0, sizeof(ctx));
        digestSize = MV_CESA_SHA1_DIGEST_SIZE;
    }
    else
    {
        mvOsPrintf("hmacGetIV: Unexpected macMode %d\n", macMode);
    }
    
    pVal32 = (MV_U32*)innerIV;
    for(i=0; i<digestSize/4; i++)
    {
        val32 = *pVal32;
        swapped32 = MV_BYTE_SWAP_32BIT(val32);
        *pVal32 = swapped32;
        pVal32++;
    }
    pVal32 = (MV_U32*)outerIV;
    for(i=0; i<digestSize/4; i++)
    {
        val32 = *pVal32;
        swapped32 = MV_BYTE_SWAP_32BIT(val32);
        *pVal32 = swapped32;
        pVal32++;
    }    
}

#ifdef MV_CESA_FRAGS_WA

void    mvCesaFragSha1Complete(MV_U8* pData, MV_U8* pOuterIV, int macLeftSize, 
                               int macTotalSize, MV_U32* pDigest)
{
    MV_SHA1_CTX ctx;
    int         i;

    /* Read temporary Digest from HW */
    for(i=0; i<MV_CESA_SHA1_DIGEST_SIZE/4; i++)
    {
        ctx.state[i] = MV_REG_READ(MV_CESA_AUTH_INIT_VALUE_DIGEST_REG(i));
    }
    memset(ctx.buffer, 0, 64);

    ctx.count[0] = ((macTotalSize - macLeftSize) * 8);
    ctx.count[1] = 0;

    if(pOuterIV != NULL)
        ctx.count[0] += (64 * 8);

    /* Complete Inner part */
    mvSHA1Update(&ctx, pData, macLeftSize);
    mvSHA1Final( (MV_U8*)pDigest, &ctx);

    if(pOuterIV != NULL)
    {
        /* Complete Outer part */
        for(i=0; i<MV_CESA_SHA1_DIGEST_SIZE/4; i++)
        {
            ctx.state[i] = MV_BYTE_SWAP_32BIT(((MV_U32*)pOuterIV)[i]);
        }
        memset(ctx.buffer, 0, 64);

        ctx.count[0] = 64*8;
        ctx.count[1] = 0;
        mvSHA1Update(&ctx, (MV_U8*)pDigest, MV_CESA_SHA1_DIGEST_SIZE);
        mvSHA1Final((MV_U8*)pDigest, &ctx);
    }

    /* Swap digest */
/*
    for(i=0; i<MV_CESA_SHA1_DIGEST_SIZE/4; i++)
    {
        pDigest[i] = MV_BYTE_SWAP_32BIT(pDigest[i]);
    }
    mvDebugMemDump(pDigest, MV_CESA_SHA1_DIGEST_SIZE, 4);
*/
}

void    mvCesaFragMd5Complete(MV_U8* pData, MV_U8* pOuterIV, int macLeftSize, 
                              int macTotalSize, MV_U32* pDigest)
{
    MV_MD5_CONTEXT  ctx;
    int             i;

    /* Read temporary Digest from HW */
    for(i=0; i<MV_CESA_MD5_DIGEST_SIZE/4; i++)
    {
        ctx.buf[i] = MV_REG_READ(MV_CESA_AUTH_INIT_VALUE_DIGEST_REG(i));
    }
    memset(ctx.in, 0, 64);

    ctx.bits[0] = ((macTotalSize - macLeftSize) * 8);
    ctx.bits[1] = 0;

    if(pOuterIV != NULL)
        ctx.bits[0] += (64 * 8);

    /* Complete Inner part */
    mvMD5Update(&ctx, pData, macLeftSize);
    mvMD5Final( (MV_U8*)pDigest, &ctx);

    if(pOuterIV != NULL)
    {
        /* Complete Outer part */
        for(i=0; i<MV_CESA_MD5_DIGEST_SIZE/4; i++)
        {
            ctx.buf[i] = MV_BYTE_SWAP_32BIT(((MV_U32*)pOuterIV)[i]);
        }
        memset(ctx.in, 0, 64);

        ctx.bits[0] = 64*8;
        ctx.bits[1] = 0;
        mvMD5Update(&ctx, (MV_U8*)pDigest, MV_CESA_MD5_DIGEST_SIZE);
        mvMD5Final((MV_U8*)pDigest, &ctx);
    }

    /* Swap digest */
/*
    for(i=0; i<MV_CESA_MD5_DIGEST_SIZE/4; i++)
    {
        pDigest[i] = MV_BYTE_SWAP_32BIT(pDigest[i]);
    }
    mvDebugMemDump(pDigest, MV_CESA_MD5_DIGEST_SIZE, 4);
*/
}

MV_STATUS   mvCesaFragAuthComplete(MV_CESA_COMMAND* pCmd, MV_CESA_SA* pSA,                            
                               int macDataSize)
{
    MV_U32*                 pDigest;
    MV_CESA_MAC_MODE        macMode;
    MV_U8*                  pOuterIV = NULL;

    /* Copy data from Source fragment to Destination using SRAM */
    mvCesaCopyFromMbuf(cesaSramVirtPtr->buf[0], pCmd->pSrc, cesaFrags.bufOffset, macDataSize);                     
    mvCesaCopyToMbuf(cesaSramVirtPtr->buf[0], pCmd->pDst, cesaFrags.bufOffset, macDataSize); 

    pDigest = (MV_U32*)(mvCesaSramAddrGet() + cesaFrags.newDigestOffset);
 
    macMode = (pSA->config & MV_CESA_MAC_MODE_MASK) >> MV_CESA_MAC_MODE_OFFSET;
/*
    mvOsPrintf("macDataSize=%d, macLength=%d, digestOffset=%d, macMode=%d\n",
            macDataSize, pCmd->macLength, pCmd->digestOffset, macMode);
*/
    switch(macMode)
    {
        case MV_CESA_MAC_HMAC_MD5:
            pOuterIV = pSA->cacheSA.macOuterIV;

        case MV_CESA_MAC_MD5:          
            mvCesaFragMd5Complete(cesaSramVirtPtr->buf[0], pOuterIV, 
                               macDataSize, pCmd->macLength, pDigest);
        break;
        
        case MV_CESA_MAC_HMAC_SHA1:
            pOuterIV = pSA->cacheSA.macOuterIV;

        case MV_CESA_MAC_SHA1:
            mvCesaFragSha1Complete(cesaSramVirtPtr->buf[0], pOuterIV, 
                               macDataSize, pCmd->macLength, pDigest);
        break;

        default:
            mvOsPrintf("mvCesaFragAuthComplete: Unexpected macMode %d\n", macMode);
            return MV_BAD_PARAM;
    }
    return MV_OK;
}
#endif /* MV_CESA_FRAGS_WA */

MV_CESA_COMMAND*    mvCesaCtrModeInit(void)
{
    MV_CESA_MBUF    *pMbuf;
    MV_U8           *pBuf;
    MV_CESA_COMMAND *pCmd;

    pBuf = mvOsMalloc(sizeof(MV_CESA_COMMAND) + 
                      sizeof(MV_CESA_MBUF) + sizeof(MV_BUF_INFO) + 100);
    if(pBuf == NULL)
    {
        mvOsPrintf("mvCesaSessionOpen: Can't allocate %d bytes for CTR Mode\n",
                    sizeof(MV_CESA_COMMAND) + sizeof(MV_CESA_MBUF) + sizeof(MV_BUF_INFO) );
        return NULL;
    }
    pCmd = (MV_CESA_COMMAND*)pBuf;
    pBuf += sizeof(MV_CESA_COMMAND);

    pMbuf = (MV_CESA_MBUF*)pBuf;
    pBuf += sizeof(MV_CESA_MBUF);

    pMbuf->pFrags = (MV_BUF_INFO*)pBuf;

    pMbuf->numFrags = 1;
    pCmd->pSrc = pMbuf;
    pCmd->pDst = pMbuf;
/*
    mvOsPrintf("CtrModeInit: pCmd=%p, pSrc=%p, pDst=%p, pFrags=%p\n",
                pCmd, pCmd->pSrc, pCmd->pDst,
                pMbuf->pFrags);
*/
    return pCmd;
}

MV_STATUS    mvCesaCtrModePrepare(MV_CESA_COMMAND *pCtrModeCmd, MV_CESA_COMMAND *pCmd)
{
    MV_CESA_MBUF    *pMbuf;
    MV_U8           *pBuf, *pIV;
    MV_U32          counter, *pCounter;
    int             cryptoSize = MV_ALIGN_UP(pCmd->cryptoLength, MV_CESA_AES_BLOCK_SIZE);
/*
    mvOsPrintf("CtrModePrepare: pCmd=%p, pCtrSrc=%p, pCtrDst=%p, pOrgCmd=%p, pOrgSrc=%p, pOrgDst=%p\n",
                pCmd, pCmd->pSrc, pCmd->pDst, 
                pCtrModeCmd, pCtrModeCmd->pSrc, pCtrModeCmd->pDst);
*/
    pMbuf = pCtrModeCmd->pSrc;

    /* Allocate buffer for Key stream */
    pBuf = mvOsIoCachedMalloc(NULL, cryptoSize, &pMbuf->pFrags[0].bufPhysAddr);
    if(pBuf == NULL)
    {
        mvOsPrintf("mvCesaCtrModePrepare: Can't allocate %d bytes\n", cryptoSize);
        return MV_OUT_OF_CPU_MEM;
    }
    memset(pBuf, 0, cryptoSize);
    mvOsCacheFlush(NULL, pBuf, cryptoSize);  

    pMbuf->pFrags[0].bufVirtPtr = pBuf;
    pMbuf->mbufSize = cryptoSize;
    pMbuf->pFrags[0].bufSize = cryptoSize;

    pCtrModeCmd->pReqPrv = pCmd->pReqPrv;
    pCtrModeCmd->sessionId = pCmd->sessionId;

    /* ivFromUser and ivOffset are don't care */
    pCtrModeCmd->cryptoOffset = 0;
    pCtrModeCmd->cryptoLength = cryptoSize;

    /* digestOffset, macOffset and macLength are don't care */

    mvCesaCopyFromMbuf(pBuf, pCmd->pSrc, pCmd->ivOffset, MV_CESA_AES_BLOCK_SIZE); 
    pCounter = (MV_U32*)(pBuf + (MV_CESA_AES_BLOCK_SIZE - sizeof(counter)));
    counter = *pCounter;
    counter = MV_32BIT_BE(counter);
    pIV = pBuf;
    cryptoSize -= MV_CESA_AES_BLOCK_SIZE;

    /* fill key stream */
    while(cryptoSize > 0)
    {
        pBuf += MV_CESA_AES_BLOCK_SIZE;
        memcpy(pBuf, pIV, MV_CESA_AES_BLOCK_SIZE - sizeof(counter));
        pCounter = (MV_U32*)(pBuf + (MV_CESA_AES_BLOCK_SIZE - sizeof(counter)));
        counter++;
        *pCounter = MV_32BIT_BE(counter);
        cryptoSize -= MV_CESA_AES_BLOCK_SIZE;
    }
    
    return MV_OK;
}

MV_STATUS   mvCesaCtrModeComplete(MV_CESA_COMMAND *pOrgCmd, MV_CESA_COMMAND *pCmd)
{
    int         srcFrag, dstFrag, srcOffset, dstOffset, keyOffset, srcSize, dstSize;
    int         cryptoSize = pCmd->cryptoLength;
    MV_U8       tempBuf[MV_CESA_MAX_BUF_SIZE]; 
    MV_U8       *pSrc, *pDst, *pKey;
    MV_STATUS   status = MV_OK;
/*
    mvOsPrintf("CtrModeComplete: pCmd=%p, pCtrSrc=%p, pCtrDst=%p, pOrgCmd=%p, pOrgSrc=%p, pOrgDst=%p\n",
                pCmd, pCmd->pSrc, pCmd->pDst, 
                pOrgCmd, pOrgCmd->pSrc, pOrgCmd->pDst);
*/
    /* XOR source data with key stream to destination data */
    pKey = pCmd->pDst->pFrags[0].bufVirtPtr;
    keyOffset = 0;

    if(pOrgCmd->pSrc != pOrgCmd->pDst)
    {
        /* Copy Prefix from source buffer to destination buffer */
/*
        status = mvCesaMbufCopy(pSA->pCtrModeCmd->pDst, 0,
                                pSA->pCtrModeCmd->pSrc, 0, pSA->pCtrModeCmd->cryptoOffset);
*/
        status = mvCesaCopyFromMbuf(tempBuf, pOrgCmd->pSrc, 
                       0, pOrgCmd->cryptoOffset);
        status = mvCesaCopyToMbuf(tempBuf, pOrgCmd->pDst, 
                       0, pOrgCmd->cryptoOffset);
    }

    srcFrag = mvCesaMbufOffset(pOrgCmd->pSrc, pOrgCmd->cryptoOffset, &srcOffset);
    pSrc = pOrgCmd->pSrc->pFrags[srcFrag].bufVirtPtr;
    srcSize = pOrgCmd->pSrc->pFrags[srcFrag].bufSize;

    dstFrag = mvCesaMbufOffset(pOrgCmd->pDst, pOrgCmd->cryptoOffset, &dstOffset);
    pDst = pOrgCmd->pDst->pFrags[dstFrag].bufVirtPtr;
    dstSize = pOrgCmd->pDst->pFrags[dstFrag].bufSize;

    while(cryptoSize > 0)
    {
        pDst[dstOffset] = (pSrc[srcOffset] ^ pKey[keyOffset]);

        cryptoSize--;
        dstOffset++;
        srcOffset++;
        keyOffset++;

        if(srcOffset >= srcSize)
        {
            srcFrag++;
            srcOffset = 0;
            pSrc = pOrgCmd->pSrc->pFrags[srcFrag].bufVirtPtr;
            srcSize = pOrgCmd->pSrc->pFrags[srcFrag].bufSize;
        }

        if(dstOffset >= dstSize)
        {
            dstFrag++;
            dstOffset = 0;
            pDst = pOrgCmd->pDst->pFrags[dstFrag].bufVirtPtr;
            dstSize = pOrgCmd->pDst->pFrags[dstFrag].bufSize;
        }
    }

    if(pOrgCmd->pSrc != pOrgCmd->pDst)
    {
        /* Copy Suffix from source buffer to destination buffer */
        srcOffset = pOrgCmd->cryptoOffset + pOrgCmd->cryptoLength;
/*
        status = mvCesaMbufCopy(pSA->pCtrModeCmd->pDst, srcOffset,
                                pSA->pCtrModeCmd->pSrc, srcOffset, 
                                pSA->pCtrModeCmd->pDst->mbufSize - srcOffset);
*/
        status = mvCesaCopyFromMbuf(tempBuf, pOrgCmd->pSrc, 
                                srcOffset, pOrgCmd->pSrc->mbufSize - srcOffset);
        status = mvCesaCopyToMbuf(tempBuf, pOrgCmd->pDst, 
                       srcOffset, pOrgCmd->pDst->mbufSize - srcOffset);
    }

    /* Free buffer used for Key stream */
    mvOsIoCachedFree(NULL, pCmd->pDst->pFrags[0].bufSize, pCmd->pDst->pFrags[0].bufPhysAddr, 
                     pCmd->pDst->pFrags[0].bufVirtPtr);

    return MV_OK;
}

void    mvCesaCtrModeFinish(MV_CESA_COMMAND* pCmd)
{
    mvOsFree(pCmd);
}


MV_STATUS   mvCesaParamCheck(MV_CESA_SA* pSA, MV_CESA_COMMAND *pCmd, MV_U8* pFixOffset)
{
    MV_U8   fixOffset = 0xFF;

    /* Check parameters */    
    if( ((pSA->config & MV_CESA_OPERATION_MASK) != 
                (MV_CESA_CRYPTO_ONLY << MV_CESA_OPERATION_OFFSET)) )
    {
        /* MAC offset should be at least 4 byte aligned */
        if( MV_IS_NOT_ALIGN(pCmd->macOffset, 4) )
        {
            mvOsPrintf("mvCesaAction: macOffset %d must be 4 byte aligned\n",
                    pCmd->macOffset);
            return MV_BAD_PARAM;
        }        
        /* Digest offset must be 4 byte aligned */
        if( MV_IS_NOT_ALIGN(pCmd->digestOffset, 4) )
        {
            mvOsPrintf("mvCesaAction: digestOffset %d must be 4 byte aligned\n",
                    pCmd->digestOffset);
            return MV_BAD_PARAM;
        }
        /* In addition all offsets should be the same alignment: 8 or 4 */
        if(fixOffset == 0xFF)
        {
            fixOffset = (pCmd->macOffset % 8);
        }
        else
        {
            if( (pCmd->macOffset % 8) != fixOffset)
            {
                mvOsPrintf("mvCesaAction: macOffset=%d must be %d byte aligned\n",
                                pCmd->macOffset, fixOffset);
                return MV_BAD_PARAM;
            }
        }
        if( (pCmd->digestOffset % 8) != fixOffset)
        {
            mvOsPrintf("mvCesaAction: digestOffset=%d must be %d byte aligned\n",
                                pCmd->digestOffset, fixOffset);
            return MV_BAD_PARAM;
        }
    }
    if( ((pSA->config & MV_CESA_OPERATION_MASK) != 
                (MV_CESA_MAC_ONLY << MV_CESA_OPERATION_OFFSET)) )
    {
        /* CryptoOffset should be at least 4 byte aligned */
        if( MV_IS_NOT_ALIGN(pCmd->cryptoOffset, 4)  )
        {
            mvOsPrintf("CesaAction: cryptoOffset=%d must be 4 byte aligned\n",
                        pCmd->cryptoOffset);
            return MV_BAD_PARAM;
        }
        /* cryptoLength should be the whole number of blocks */
        if( MV_IS_NOT_ALIGN(pCmd->cryptoLength, pSA->cryptoBlockSize) ) 
        {
            mvOsPrintf("mvCesaAction: cryptoLength=%d must be %d byte aligned\n",
                        pCmd->cryptoLength, pSA->cryptoBlockSize);
            return MV_BAD_PARAM;
        }
        if(fixOffset == 0xFF)
        {
            fixOffset = (pCmd->cryptoOffset % 8);
        }
        else
        {
            /* In addition all offsets should be the same alignment: 8 or 4 */
            if( (pCmd->cryptoOffset % 8) != fixOffset) 
            {
                mvOsPrintf("mvCesaAction: cryptoOffset=%d, must be %d byte aligned\n",
                                pCmd->cryptoOffset, fixOffset);
                return MV_BAD_PARAM;
            }
        }
 
        /* check for CBC mode */
        if(pSA->cryptoIvSize > 0)
        {
            /* ivOffset must be 4 byte aligned */
            if( MV_IS_NOT_ALIGN(pCmd->ivOffset, 4) )
            {
                mvOsPrintf("CesaAction: ivOffset=%d must be 4 byte aligned\n",
                            pCmd->ivOffset);
                return MV_BAD_PARAM;
            }            
            /* In addition all offsets should be the same alignment: 8 or 4 */
            if( (pCmd->ivOffset % 8) != fixOffset) 
            {
                mvOsPrintf("mvCesaAction: ivOffset=%d, must be %d byte aligned\n",
                                pCmd->ivOffset, fixOffset);
                return MV_BAD_PARAM;
            }
        }
    }
    return MV_OK;
}

MV_STATUS   mvCesaFragParamCheck(MV_CESA_SA* pSA, MV_CESA_COMMAND *pCmd)
{
    int     offset;

#ifdef MV_CESA_FRAGS_WA
    /* Crypto and HMAC operation for fragmented packets is not supported */
    if( ((pSA->config & MV_CESA_OPERATION_MASK) == 
            (MV_CESA_MAC_THEN_CRYPTO << MV_CESA_OPERATION_OFFSET)) ||
        ((pSA->config & MV_CESA_OPERATION_MASK) == 
            (MV_CESA_CRYPTO_THEN_MAC << MV_CESA_OPERATION_OFFSET)) )
    {
        mvOsPrintf("CesaAction: CRYPTO and MAC not supported for fragmented packets\n");
        return MV_NOT_ALLOWED;
    }    
#endif /* MV_CESA_FRAGS_WA */

    if( ((pSA->config & MV_CESA_OPERATION_MASK) != 
                (MV_CESA_CRYPTO_ONLY << MV_CESA_OPERATION_OFFSET)) )
    {
        /* macOffset must be less that SRAM buffer size */
        if(pCmd->macOffset > (sizeof(cesaSramVirtPtr->buf) - MV_CESA_AUTH_BLOCK_SIZE))
        {
            mvOsPrintf("mvCesaFragParamCheck: macOffset is too large (%d)\n",
                        pCmd->macOffset);
            return MV_BAD_PARAM;
        }
        /* macOffset+macSize must be more than mbufSize - SRAM buffer size */ 
        if( ((pCmd->macOffset + pCmd->macLength) > pCmd->pSrc->mbufSize) ||
            ((pCmd->pSrc->mbufSize - (pCmd->macOffset + pCmd->macLength)) >=
             sizeof(cesaSramVirtPtr->buf)) )
        {
            mvOsPrintf("mvCesaFragParamCheck: macLength is too small (%d), mbufSize=%d\n",
                        pCmd->macLength, pCmd->pSrc->mbufSize);
            return MV_BAD_PARAM;
        }
    }

    if( ((pSA->config & MV_CESA_OPERATION_MASK) != 
                (MV_CESA_MAC_ONLY << MV_CESA_OPERATION_OFFSET)) )
    {
        /* cryptoOffset must be less that SRAM buffer size */
        /* 4 for possible fixOffset */
        if( (pCmd->cryptoOffset + 4) > (sizeof(cesaSramVirtPtr->buf) - pSA->cryptoBlockSize))
        {
            mvOsPrintf("mvCesaFragParamCheck: cryptoOffset is too large (%d)\n",
                        pCmd->cryptoOffset);
            return MV_BAD_PARAM;
        }

        /* cryptoOffset+cryptoSize must be more than mbufSize - SRAM buffer size */ 
        if( ((pCmd->cryptoOffset + pCmd->cryptoLength) > pCmd->pSrc->mbufSize) ||
            ((pCmd->pSrc->mbufSize - (pCmd->cryptoOffset + pCmd->cryptoLength)) >=
             (sizeof(cesaSramVirtPtr->buf) - pSA->cryptoBlockSize)) )
        {
            mvOsPrintf("mvCesaFragParamCheck: cryptoLength is too small (%d), mbufSize=%d\n",
                        pCmd->cryptoLength, pCmd->pSrc->mbufSize);
            return MV_BAD_PARAM;
        }
    }

    /* When MAC_THEN_CRYPTO or CRYPTO_THEN_MAC */
    /* abs(cryptoOffset-macOffset) must be aligned cryptoBlockSize */
    if( ((pSA->config & MV_CESA_OPERATION_MASK) == 
            (MV_CESA_MAC_THEN_CRYPTO << MV_CESA_OPERATION_OFFSET)) ||
        ((pSA->config & MV_CESA_OPERATION_MASK) == 
            (MV_CESA_CRYPTO_THEN_MAC << MV_CESA_OPERATION_OFFSET)) )
    {
        if(pCmd->cryptoOffset > pCmd->macOffset)
        {
            offset = pCmd->cryptoOffset - pCmd->macOffset;
        }
        else
        {
            offset = pCmd->macOffset - pCmd->cryptoOffset;
        }

        if( MV_IS_NOT_ALIGN(offset,  pSA->cryptoBlockSize) )
        {
            mvOsPrintf("mvCesaFragParamCheck: cryptoOffset - macOffset must be %d byte aligned\n",
                        pSA->cryptoBlockSize);
            return MV_NOT_ALLOWED;
        }
        /* Digest must not be part of CryptoLength */
        if( ((pCmd->digestOffset + pSA->digestSize) > pCmd->cryptoOffset) &&
            (pCmd->digestOffset < (pCmd->cryptoOffset + pCmd->cryptoLength)) )
        {
            mvOsPrintf("mvCesaFragParamCheck: digestOffset (%d) is part of cryptoLength (%d+%d)\n",
                        pCmd->digestOffset, pCmd->cryptoOffset, pCmd->cryptoLength);
            return MV_NOT_ALLOWED;
        }
        /* cryptoIV must not be part of macLength */
        if( ((pCmd->ivOffset + pSA->cryptoIvSize) > pCmd->macOffset) &&
            (pCmd->ivOffset < (pCmd->macOffset + pCmd->macLength)) )
        {
            mvOsPrintf("mvCesaFragParamCheck: cryptoIvOffset (%d) is part of macLength (%d+%d)\n",
                        pCmd->ivOffset, pCmd->macOffset, pCmd->macLength);
            return MV_NOT_ALLOWED;
        }
    }
    return MV_OK;
}

void   mvCesaFragSizeFind(MV_CESA_SA* pSA, MV_CESA_COMMAND *pCmd, 
                          int cryptoOffset, int macOffset,
                          int* pCopySize, int* pCryptoDataSize, int* pMacDataSize)
{
    int cryptoDataSize, macDataSize, copySize;

    cryptoDataSize = macDataSize = 0;
    copySize = *pCopySize;

    if( (pSA->config & MV_CESA_OPERATION_MASK) != 
                (MV_CESA_MAC_ONLY << MV_CESA_OPERATION_OFFSET) )
    {
        cryptoDataSize = MV_MIN( (copySize - cryptoOffset), 
                                 (pCmd->cryptoLength - (cesaFrags.cryptoSize + 1)) );

        /* cryptoSize for each fragment must be the whole number of blocksSize */
        if( MV_IS_NOT_ALIGN(cryptoDataSize, pSA->cryptoBlockSize) )
        {
            cryptoDataSize = MV_ALIGN_DOWN(cryptoDataSize, pSA->cryptoBlockSize);
            copySize = cryptoOffset + cryptoDataSize;
        }
    }
    if( (pSA->config & MV_CESA_OPERATION_MASK) != 
             (MV_CESA_CRYPTO_ONLY << MV_CESA_OPERATION_OFFSET) )
    {
        macDataSize = MV_MIN( (copySize - macOffset), 
                              (pCmd->macLength - (cesaFrags.macSize + 1)));

        /* macSize for each fragment (except last) must be the whole number of blocksSize */
        if( MV_IS_NOT_ALIGN(macDataSize, MV_CESA_AUTH_BLOCK_SIZE) )
        {
            macDataSize = MV_ALIGN_DOWN(macDataSize, MV_CESA_AUTH_BLOCK_SIZE);
            copySize = macOffset + macDataSize;
        }
        cryptoDataSize = copySize - cryptoOffset; 
    }
    *pCopySize = copySize;
    
    if(pCryptoDataSize != NULL)
        *pCryptoDataSize = cryptoDataSize;

    if(pMacDataSize != NULL)
        *pMacDataSize = macDataSize;
}
